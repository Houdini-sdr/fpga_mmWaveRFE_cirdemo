module CIR_Extract_1x1_Tx_top #(
    parameter DATA_WIDTH = 16
) (
    input  en,
    input  rst_n,
    input  clk,
    output BD_real,
    output PD_real,
    output ctrl_sync,
    output [8*DATA_WIDTH-1:0] I_tdata,
    output [8*DATA_WIDTH-1:0] Q_tdata,
    output I_tvalid,
    output Q_tvalid,
    input  I_tready,
    input  Q_tready,
    // AXI Settings
    input [15:0] REAL_PD_SHIFT,
    input  [DATA_WIDTH-1:0] AMPLITUDE, // amplitude of DAC output
    input  [15:0] DELAY, // CC delay after transmitting one header
    input  [15:0] HEADER_PER_FRAME  // for each enable, 
);
    wire rst;
    assign rst = !rst_n;
    
    reg [15:0] Tx_count;    // Kai 0528 
    wire Tx_done;            // Kai 0528
    assign Tx_done = (Tx_count == HEADER_PER_FRAME);
    
    reg ctrl_sync;

    reg [15:0] cnt;
    reg [127:0] Ga = 128'b11000000010110011100111101010110001111111010011011001111010101101100000001011001110011110101011011000000010110010011000010101001;
    reg [127:0] Gb = 128'b00111111101001100011000010101001110000000101100100110000101010011100000001011001110011110101011011000000010110010011000010101001;

    //wire [(17+9)*128-1:0] G = {
    wire [0:(17+9)*128-1] G = {     // Kai 07/05/2024
        Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, Ga, -Ga, // STF
        -Gb, -Ga, Gb, -Ga, -Gb, Ga, -Gb, -Ga, -Gb // CES
    };

    wire [DATA_WIDTH-1:0] Ir[0:7], Qr[0:7];
    reg  [7:0] I;

    wire i_ready = I_tready & Q_tready;
    reg  o_valid;
    
    assign I_tvalid = o_valid;
    assign Q_tvalid = o_valid;
    
    assign PD_real = cnt >= REAL_PD_SHIFT + 16'd16 & cnt <= REAL_PD_SHIFT + 16'd290;
    assign BD_real = cnt >= REAL_PD_SHIFT + 16'd256 & cnt <= REAL_PD_SHIFT + 16'd290;
    
    assign I_tdata = { Ir[7], Ir[6], Ir[5], Ir[4], Ir[3], Ir[2], Ir[1], Ir[0] };
    assign Q_tdata = { Qr[7], Qr[6], Qr[5], Qr[4], Qr[3], Qr[2], Qr[1], Qr[0] };

    genvar i;
    generate
        for (i = 0; i != 8; i = i + 1) begin: ROT
            Rotate rot (
                .en(o_valid),
                .ang(i[1:0]),
                .i(I[i]),
                .A(AMPLITUDE),
                .I_o(Ir[i]),
                .Q_o(Qr[i])
            );
        end
    endgenerate

    integer j;
    always@(posedge clk, posedge rst) begin
        if (rst) begin
            cnt <= 0;
            o_valid <= 0;
            Tx_count <= 0;  // Kai 0528
            ctrl_sync <= 0; // kai 0529
        end
        else begin
            if (!en) begin  // Kai 0528
                Tx_count <= 0;
                ctrl_sync <= 0;
            end             
            if (en & i_ready & !Tx_done) begin
                ctrl_sync <= 1;  // kai 0529
                if (cnt <= (17+9)*128 / 8) begin
                    o_valid <= 1;
                    for (j = 0; j != 8; j = j + 1) begin
                        I[j] <= G[8*cnt+j];
                    end
                    cnt <= cnt + 1;
                end
                else if (cnt <= (17+9)*128 / 8 + DELAY) begin
                    o_valid <= 0;
                    cnt <= cnt + 1;
                end
                else begin 
                    cnt <= 0;
                    o_valid <= 0;
                    Tx_count <= Tx_count + 1;
                end
            end
            else begin
                o_valid <= 0;
                ctrl_sync <= 0;
            end
        end
    end

endmodule
